simpleFrameworks.addto('iModHeader', 'appendBug');
simpleFrameworks.addto('iModOptions', 'bugSetting');